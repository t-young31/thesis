#!/bin/csh
#
#$ -cwd
#
#$ -pe smp 4
#$ -l s_rt=360:00:00
#
module load mpi/openmpi3-x86_64
setenv ORIG $PWD
setenv SCR $TMPDIR
mkdir -p $SCR
cp septamer5_sp.inp $SCR
#
cd $SCR
/usr/local/orca_4_1_1_linux_x86-64/orca septamer5_sp.inp > septamer5_sp.out
rm -f *.tmp
cp *.out *.xyz $ORIG
cd / 
rm -Rf $SCR
cd $ORIG
rm *.sh.*
