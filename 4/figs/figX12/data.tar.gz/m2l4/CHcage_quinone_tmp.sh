#!/bin/bash
#
#$ -cwd
#
#$ -pe smp 16
#$ -l s_rt=360:00:00
#
module load mpi/openmpi3-x86_64
export PATH=/usr/local/orca_4_1_0_linux_x86-64:$PATH
export ORIG=$PWD
export SCR=$TMPDIR
export NBOEXE=/usr/local/nbo7/bin/nbo7.i4.exe
cp CHcage_quinone_tmp.inp $SCR
#
cd $SCR
/usr/local/orca_4_2_1_linux_x86-64/orca CHcage_quinone_tmp.inp > CHcage_quinone_tmp.out
rm -f *.tmp
cp *.xyz *.out $ORIG
rm *.sh.*
