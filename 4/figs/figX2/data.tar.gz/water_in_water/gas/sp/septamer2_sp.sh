#!/bin/bash
#
#$ -cwd
#
#$ -pe smp 8
#$ -l s_rt=360:00:00
#
module load mpi/openmpi3-x86_64
export PATH=/usr/local/orca_4_1_0_linux_x86-64:$PATH
export ORIG=$PWD
export SCR=$TMPDIR
export NBOEXE=/usr/local/nbo7/bin/nbo7.i4.exe
cp septamer2_sp.inp $SCR
#
cd $SCR
/usr/local/orca_4_2_1_linux_x86-64/orca septamer2_sp.inp > septamer2_sp.out
rm -f *.tmp
cp *.xyz *.out $ORIG
rm *.sh.*
